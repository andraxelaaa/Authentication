<?php
    session_start();
?>
<html>
<head>
    <title></title>
    <style type="text/css">
        a{
            width: 100px;
            height: 35px;
            border-radius: 15px;
            background-color: green;
            border: solid 2px green;
            color: white;
            margin-left: 145px;
            padding: 20px;
            color: black;
        }
    </style>
</head>
<body style="background-color:#A5AAAB;">
    <a href='process.php'>LOG OFF!</a>
</body>
</html>